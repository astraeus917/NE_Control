from django.contrib import admin
from .models import NoteNE, ActionTaken, Claim

admin.site.register(NoteNE)
admin.site.register(ActionTaken)
admin.site.register(Claim)


