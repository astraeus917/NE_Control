from django.apps import AppConfig


class NeControlConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ne_control'
